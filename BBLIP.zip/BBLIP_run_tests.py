## Import packages.

import gurobipy as gp
from gurobipy import GRB

import math
import time

import os
import json

options = {
    "WLSACCESSID": "365c04ea-c99c-4a13-a235-6b1e7a34f04c",
    "WLSSECRET":   "d461a18b-647a-43aa-a70a-7e3b94e21296",
    "LICENSEID":   2458765
}

## Adjust Gurobi model parameters.

# Specify whether to enables console logging (=1 enable, =0 disable).

value_LogToConsole = 0
value_LogToConsole_LP = 0
value_LogToConsole_big_M = 0

# Specify the primal feasibility tolerance (=1e-6 default, =1e-9 minimum, =1e-2 maximum).

value_FeasibilityTol = 1e-6
value_FeasibilityTol_LP = 1e-6
value_FeasibilityTol_big_M = 1e-6

# Specify the integer feasibility tolerance (=1e-5 default, =1e-9 minimum, =1e-1 maximum).

value_IntFeasTol = 1e-5
value_IntFeasTol_LP = 1e-5
value_IntFeasTol_big_M = 1e-5

# Specify the limits the total time expended (in seconds) (=Infinity default, =0 minimum, =Infinity maximum).

value_Timelimit = 3600
value_Timelimit_LP = 3600
value_Timelimit_big_M = 3600

## Define functions solving the BBLIP under reformulation R1.

# Solve the problem under R1.

def solve_R1(M, M_tilde, t_R1, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f):

    with gp.Model(env=env) as model:
    
        start_time = time.time()
        
        x = model.addVars(q_1, vtype=GRB.BINARY, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta") 
        
        u = model.addVars(m, vtype=GRB.BINARY, name="u")
        v = model.addVars(n, vtype=GRB.BINARY, name="v")
        
        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))
        
        model.addConstrs(f[j] - sum(F[j][i]*y[i] for i in range(n)) - sum(L[j][i]*x[i] for i in range(q_1)) - sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= M*u[j] for j in range(m))
        model.addConstrs(theta[i] <= M*(1-u[i]) for i in range(m))
        
        model.addConstrs(sum(F[i][j]*theta[i] for i in range(m)) - c[j] <= M_tilde*v[j] for j in range(n))
        model.addConstrs(y[i] <= M_tilde*(1-v[i]) for i in range(n))
        
        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    
        
        model.setParam('LogToConsole', value_LogToConsole)
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()
        
        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            gap = model.getAttr("MIPGap")
            return dict(optval=float('nan'), solution=float('nan'), gap=gap, time=end_time+t_R1)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            gap = model.getAttr("MIPGap")
            return dict(optval=optval, solution=solution, gap=gap, time=end_time+t_R1)

# Solve the LP problem under R1.

def solve_R1_LP(M, M_tilde, t_R1, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f):

    with gp.Model(env=env) as model:

        start_time = time.time()

        x = model.addVars(q_1, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta") 
        
        u = model.addVars(m, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="u")
        v = model.addVars(n, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="v")
        
        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))
        
        model.addConstrs(f[j] - sum(F[j][i]*y[i] for i in range(n)) - sum(L[j][i]*x[i] for i in range(q_1)) - sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= M*u[j] for j in range(m))
        model.addConstrs(theta[i] <= M*(1-u[i]) for i in range(m))
        
        model.addConstrs(sum(F[i][j]*theta[i] for i in range(m)) - c[j] <= M_tilde*v[j] for j in range(n))
        model.addConstrs(y[i] <= M_tilde*(1-v[i]) for i in range(n))
        
        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    
        
        model.setParam('LogToConsole', value_LogToConsole)
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()

        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            return dict(optval=float('nan'), solution=float('nan'), time=end_time+t_R1)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            return dict(optval=optval, solution=solution, time=end_time+t_R1)
    
## Define functions solving the BBLIP under reformulation L2.

# Solve the problem under L2.

def solve_L2(theta_ub, theta_lb, t_L2, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, T):

    with gp.Model(env=env) as model:

        start_time = time.time()

        x = model.addVars(q_1, vtype=GRB.BINARY, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta") 

        v = model.addVars(q_1, m, vtype=GRB.CONTINUOUS, name="v")
        z = model.addVars(q_2, T, vtype=GRB.BINARY, name="z")
        u = model.addVars(q_2, m, T, vtype=GRB.CONTINUOUS, name="u")

        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))

        model.addConstrs(v[i,k] <= theta_ub[k]*x[i] for i in range(q_1) for k in range(m))
        model.addConstrs(v[i,k] <= theta[k] + theta_lb[k]*x[i] - theta_lb[k] for i in range(q_1) for k in range(m))
        model.addConstrs(v[i,k] >= theta_lb[k]*x[i] for i in range(q_1) for k in range(m))
        model.addConstrs(v[i,k] >= theta[k] + theta_ub[k]*x[i] - theta_ub[k] for i in range(q_1) for k in range(m))

        model.addConstrs(u[i,k,t] <= theta_ub[k]*z[i,t] for t in range(T) for i in range(q_2) for k in range(m))
        model.addConstrs(u[i,k,t] <= theta[k] + theta_lb[k]*z[i,t] - theta_lb[k] for t in range(T) for i in range(q_2) for k in range(m))
        model.addConstrs(u[i,k,t] >= theta_lb[k]*z[i,t] for i in range(q_2) for t in range(T) for k in range(m))
        model.addConstrs(u[i,k,t] >= theta[k] + theta_ub[k]*z[i,t] - theta_ub[k] for t in range(T) for i in range(q_2) for k in range(m))

        model.addConstrs(x_c[i] == sum(2**(-t)*z[i,t] for t in range(T)) for i in range(q_2))
        model.addConstr(sum(c[i]*y[i] for i in range(n)) + sum(L[k][i]*v[i,k] for i in range(q_1) for k in range(m)) + sum(2**(-t)*L[k][q_1+i]*u[i,k,t] for t in range(T) for i in range(q_2) for k in range(m)) == sum(f[i]*theta[i] for i in range(m)))

        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    

        model.setParam('LogToConsole', value_LogToConsole)
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()
        
        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            gap = model.getAttr("MIPGap")
            return dict(optval=float('nan'), solution=float('nan'), gap=gap, time=end_time+t_L2)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            gap = model.getAttr("MIPGap")
            return dict(optval=optval, solution=solution, gap=gap, time=end_time+t_L2)

# Solve the LP problem under L2.

def solve_L2_LP(theta_ub, theta_lb, t_L2, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, T):

    with gp.Model(env=env) as model:

        start_time = time.time()
  
        x = model.addVars(q_1, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta") 

        v = model.addVars(q_1, m, vtype=GRB.CONTINUOUS, name="v")
        z = model.addVars(q_2, T, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="z")
        u = model.addVars(q_2, m, T, vtype=GRB.CONTINUOUS, name="u")


        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))

        model.addConstrs(v[i,k] <= theta_ub[k]*x[i] for i in range(q_1) for k in range(m))
        model.addConstrs(v[i,k] <= theta[k] + theta_lb[k]*x[i] - theta_lb[k] for i in range(q_1) for k in range(m))
        model.addConstrs(v[i,k] >= theta_lb[k]*x[i] for i in range(q_1) for k in range(m))
        model.addConstrs(v[i,k] >= theta[k] + theta_ub[k]*x[i] - theta_ub[k] for i in range(q_1) for k in range(m))

        model.addConstrs(u[i,k,t] <= theta_ub[k]*z[i,t] for t in range(T) for i in range(q_2) for k in range(m))
        model.addConstrs(u[i,k,t] <= theta[k] + theta_lb[k]*z[i,t] - theta_lb[k] for t in range(T) for i in range(q_2) for k in range(m))
        model.addConstrs(u[i,k,t] >= theta_lb[k]*z[i,t] for i in range(q_2) for t in range(T) for k in range(m))
        model.addConstrs(u[i,k,t] >= theta[k] + theta_ub[k]*z[i,t] - theta_ub[k] for t in range(T) for i in range(q_2) for k in range(m))

        model.addConstrs(x_c[i] == sum(2**(-t)*z[i,t] for t in range(T)) for i in range(q_2))
        model.addConstr(sum(c[i]*y[i] for i in range(n)) + sum(L[k][i]*v[i,k] for i in range(q_1) for k in range(m)) + sum(2**(-t)*L[k][q_1+i]*u[i,k,t] for t in range(T) for i in range(q_2) for k in range(m)) == sum(f[i]*theta[i] for i in range(m)))

        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    

        model.setParam('LogToConsole', value_LogToConsole)
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()
        
        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            return dict(optval=float('nan'), solution=float('nan'), time=end_time+t_L2)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            return dict(optval=optval, solution=solution, time=end_time+t_L2)

## Define functions solving the BBLIP under reformulation L3.

# Solve the problem under L3.

def solve_L3(L_theta_ub, L_theta_lb, t_L3, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, T):

    with gp.Model(env=env) as model:

        start_time = time.time()

        x = model.addVars(q_1, vtype=GRB.BINARY, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta") 

        v = model.addVars(q_1, vtype=GRB.CONTINUOUS, name="v")
        z = model.addVars(q_2, T, vtype=GRB.BINARY, name="z")
        u = model.addVars(q_2, T, vtype=GRB.CONTINUOUS, name="u")

        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))

        model.addConstrs(v[i] <= L_theta_ub[i]*x[i] for i in range(q_1))
        model.addConstrs(v[i] <= sum(L[k][i]*theta[k] for k in range(m)) + L_theta_lb[i]*x[i] - L_theta_lb[i] for i in range(q_1))
        model.addConstrs(v[i] >= L_theta_lb[i]*x[i] for i in range(q_1))
        model.addConstrs(v[i] >= sum(L[k][i]*theta[k] for k in range(m)) + L_theta_ub[i]*x[i] - L_theta_ub[i] for i in range(q_1))

        model.addConstrs(u[i,t] <= L_theta_ub[q_1+i]*z[i,t] for t in range(T) for i in range(q_2))
        model.addConstrs(u[i,t] <= sum(L[k][q_1+i]*theta[k] for k in range(m)) + L_theta_lb[q_1+i]*z[i,t] - L_theta_lb[q_1+i] for t in range(T) for i in range(q_2))
        model.addConstrs(u[i,t] >= L_theta_lb[q_1+i]*z[i,t] for i in range(q_2) for t in range(T))
        model.addConstrs(u[i,t] >= sum(L[k][q_1+i]*theta[k] for k in range(m)) + L_theta_ub[q_1+i]*z[i,t] - L_theta_ub[q_1+i] for t in range(T) for i in range(q_2))

        model.addConstrs(x_c[i] == sum(2**(-t)*z[i,t] for t in range(T)) for i in range(q_2))
        model.addConstr(sum(c[i]*y[i] for i in range(n)) + sum(v[i] for i in range(q_1)) + sum(2**(-t)*u[i,t] for t in range(T) for i in range(q_2)) == sum(f[i]*theta[i] for i in range(m)))

        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    

        model.setParam('LogToConsole', value_LogToConsole)
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()
        
        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            gap = model.getAttr("MIPGap")
            return dict(optval=float('nan'), solution=float('nan'), gap=gap, time=end_time+t_L3)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            gap = model.getAttr("MIPGap")
            return dict(optval=optval, solution=solution, gap=gap, time=end_time+t_L3)

# Solve the LP problem under L3.

def solve_L3_LP(L_theta_ub, L_theta_lb, t_L3, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, T):

    with gp.Model(env=env) as model:

        start_time = time.time()

        x = model.addVars(q_1, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta")  

        v = model.addVars(q_1, vtype=GRB.CONTINUOUS, name="v")
        z = model.addVars(q_2, T, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="z")
        u = model.addVars(q_2, T, vtype=GRB.CONTINUOUS, name="u")

        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))

        model.addConstrs(v[i] <= L_theta_ub[i]*x[i] for i in range(q_1))
        model.addConstrs(v[i] <= sum(L[k][i]*theta[k] for k in range(m)) + L_theta_lb[i]*x[i] - L_theta_lb[i] for i in range(q_1))
        model.addConstrs(v[i] >= L_theta_lb[i]*x[i] for i in range(q_1))
        model.addConstrs(v[i] >= sum(L[k][i]*theta[k] for k in range(m)) + L_theta_ub[i]*x[i] - L_theta_ub[i] for i in range(q_1))

        model.addConstrs(u[i,t] <= L_theta_ub[q_1+i]*z[i,t] for t in range(T) for i in range(q_2))
        model.addConstrs(u[i,t] <= sum(L[k][q_1+i]*theta[k] for k in range(m)) + L_theta_lb[q_1+i]*z[i,t] - L_theta_lb[q_1+i] for t in range(T) for i in range(q_2))
        model.addConstrs(u[i,t] >= L_theta_lb[q_1+i]*z[i,t] for i in range(q_2) for t in range(T))
        model.addConstrs(u[i,t] >= sum(L[k][q_1+i]*theta[k] for k in range(m)) + L_theta_ub[q_1+i]*z[i,t] - L_theta_ub[q_1+i] for t in range(T) for i in range(q_2))

        model.addConstrs(x_c[i] == sum(2**(-t)*z[i,t] for t in range(T)) for i in range(q_2))
        model.addConstr(sum(c[i]*y[i] for i in range(n)) + sum(v[i] for i in range(q_1)) + sum(2**(-t)*u[i,t] for t in range(T) for i in range(q_2)) == sum(f[i]*theta[i] for i in range(m)))

        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    

        model.setParam('LogToConsole', value_LogToConsole)
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()
        
        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            return dict(optval=float('nan'), solution=float('nan'), time=end_time+t_L3)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            return dict(optval=optval, solution=solution, time=end_time+t_L3)
     
## Define functions solving the BBLIP using CS-based approach with SOS1 constraints.

# Solve the problem using CS-based approach.

def solve_SOS(q_1, q_2, n, p, m, a, c, d, H, h, F, L, f):

    with gp.Model(env=env) as model:
    
        start_time = time.time()
        
        x = model.addVars(q_1, vtype=GRB.BINARY, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta") 
        
        u = model.addVars(m, vtype=GRB.CONTINUOUS, name="u")
        v = model.addVars(n, vtype=GRB.CONTINUOUS, name="v")
        
        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))

        model.addConstrs(u[j] == f[j] - sum(F[j][i]*y[i] for i in range(n)) - sum(L[j][i]*x[i] for i in range(q_1)) - sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) for j in range(m))
        for j in range(m):
            model.addSOS(GRB.SOS_TYPE1, [u[j], theta[j]], [1, 2])

        model.addConstrs(v[j] == sum(F[i][j]*theta[i] for i in range(m)) - c[j] for j in range(n))
        for j in range(n):
            model.addSOS(GRB.SOS_TYPE1, [v[j], y[j]], [1, 2])

        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    
        
        model.setParam('LogToConsole', value_LogToConsole)
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()
        
        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            gap = model.getAttr("MIPGap")
            return dict(optval=float('nan'), solution=float('nan'), gap=gap, time=end_time)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            gap = model.getAttr("MIPGap")
            return dict(optval=optval, solution=solution, gap=gap, time=end_time)
    
## Define functions solving the BBLIP using SD-based approach with bilinear constraints.

# Solve the problem using SD-based approach.

def solve_BL(q_1, q_2, n, p, m, a, c, d, H, h, F, L, f):

    with gp.Model(env=env) as model:

        start_time = time.time()
 
        x = model.addVars(q_1, vtype=GRB.BINARY, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta") 

        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))

        model.addConstr(sum(c[i]*y[i] for i in range(n)) == sum(f[i]*theta[i] for i in range(m)) - sum(L[k][i]*theta[k]*x[i] for i in range(q_1) for k in range(m)) - sum(L[k][q_1+i]*theta[k]*x_c[i] for i in range(q_2) for k in range(m)))

        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    

        model.setParam('LogToConsole', value_LogToConsole)
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()
        
        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            gap = model.getAttr("MIPGap")
            return dict(optval=float('nan'), solution=float('nan'), gap=gap, time=end_time)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            gap = model.getAttr("MIPGap")
            return dict(optval=optval, solution=solution, gap=gap, time=end_time)

## Bounded Bilevel Linear Integer Problem (BBLIP) ##

## Define a function solving the upper-bound of dual objective using LP.

def solve_obj_ub(m, n, f, L, c):

    with gp.Model(env=env) as model:
           
        x = model.addVars(q_1, vtype=GRB.BINARY, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="y")
        
        model.addConstrs( sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m-n))

        model.setObjective(sum(c[i]*y[i] for i in range(n)), GRB.MAXIMIZE)
        
        model.setParam('LogToConsole', value_LogToConsole)
        model.optimize()
        
        optval = model.getAttr("ObjVal")
        
        return optval
    
## Define a function solving the lower-bound of (f-Lx) using LP.

def solve_fLx_lb(p, f, L, H, h, k):

    with gp.Model(env=env) as model:
        
        x = model.addVars(q_1, vtype=GRB.BINARY, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")

        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))

        model.setObjective(f[k] - sum(L[k][i]*x[i] for i in range(q_1)) + sum(L[k][q_1+i]*x_c[i] for i in range(q_2)), GRB.MINIMIZE)
        
        model.setParam('LogToConsole', value_LogToConsole)
        model.optimize()
        
        optval = model.getAttr("ObjVal")
        
        return optval

## Define functions solving the upper-bounds of dual variables using LP.

def solve_theta_ub_1(obj_ub, fLx_lb, m, n, k):

    with gp.Model(env=env) as model:

        theta_1 = model.addVars(m-n, lb=0, vtype=GRB.CONTINUOUS, name="theta 1") 
        theta_2 = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="theta 2") 

        model.addConstr(sum(fLx_lb[j]*theta_1[j] for j in range(m-n)) + sum(theta_2[i] for i in range(n)) <= obj_ub)

        model.setObjective(theta_1[k], GRB.MAXIMIZE)
        
        model.setParam('LogToConsole', value_LogToConsole)
        model.optimize()
        
        optval = model.getAttr("ObjVal")
        
        return optval

def solve_theta_ub_2(obj_ub, fLx_lb, m, n, k):

    with gp.Model(env=env) as model:

        theta_1 = model.addVars(m-n, lb=0, vtype=GRB.CONTINUOUS, name="theta 1") 
        theta_2 = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="theta 2") 

        model.addConstr(sum(fLx_lb[j]*theta_1[j] for j in range(m-n)) + sum(theta_2[i] for i in range(n)) <= obj_ub)

        model.setObjective(theta_2[k], GRB.MAXIMIZE)
        
        model.setParam('LogToConsole', value_LogToConsole)
        model.optimize()
        
        optval = model.getAttr("ObjVal")
        
        return optval

## Define functions solving the upper-bounds of sum_k(L_ki*theta_k) using LP.

def solve_L_theta_ub(obj_ub, fLx_lb, m, n, L, i):

    with gp.Model(env=env) as model:

        theta_1 = model.addVars(m-n, lb=0, vtype=GRB.CONTINUOUS, name="theta 1") 
        theta_2 = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="theta 2") 

        model.addConstr(sum(fLx_lb[j]*theta_1[j] for j in range(m-n)) + sum(theta_2[i] for i in range(n)) <= obj_ub)

        model.setObjective(sum(L[k][i]*theta_1[k] for k in range(m-n)) + sum(L[m-n+k][i]*theta_2[k] for k in range(n)), GRB.MAXIMIZE)
        
        model.setParam('LogToConsole', value_LogToConsole)
        model.optimize()
        
        optval = model.getAttr("ObjVal")
        
        return optval

## Import test instances from .json file.

json_path = os.getcwd()
file_name = 'BBLIP_test_instances.json'
fname = os.path.join(json_path, file_name)

# Open .json file.
file = open(fname) 
 
# Return .json object as a dictionary.
inst_storage = json.load(file)

# Close .json file.
file.close()

## Run experiments with random test instances of the different sizes.

sol_storage = dict()
big_M_storage = dict()

with gp.Env(params=options) as env:

    for num_T in range(2):

        sol_storage_T = dict()
        big_M_storage_T = dict()

        T = 4 + 3*num_T

        for size in range(len(inst_storage)):

            multiple_sol = dict()
            multiple_big_M = dict()

            for count in range(len(inst_storage[str(size)])):
                
                # Prepare random test instances for BBLIP parameters.
                
                p = inst_storage[str(size)][str(count)]["p"]
                q_1 = inst_storage[str(size)][str(count)]["q_1"]
                q_2 = inst_storage[str(size)][str(count)]["q_2"]
                q = q_1 + q_2
                m = inst_storage[str(size)][str(count)]["m"]
                n = inst_storage[str(size)][str(count)]["n"]
                a = inst_storage[str(size)][str(count)]["a"]
                c = inst_storage[str(size)][str(count)]["c"]
                d = inst_storage[str(size)][str(count)]["d"]
                H = inst_storage[str(size)][str(count)]["H"]
                h = inst_storage[str(size)][str(count)]["h"]
                F = inst_storage[str(size)][str(count)]["F"]
                L = inst_storage[str(size)][str(count)]["L"]
                f = inst_storage[str(size)][str(count)]["f"]

                sol = {"p": p, "q_1": q_1, "q_2": q_2, "q": q, "m": m, "n": n, "a": a, "c": c, "d": d, "H": H, "h": h, "F": F, "L": L, "f": f, "T": T}

                # Solve for the upper- and lower-bound of dual variables theta_k.
                
                start_time = time.time()
                
                obj_ub = solve_obj_ub(m, n, f, L, c) # solving for the upper-bound of dual objective

                fLx_lb = []
                for k in range(m-n):
                    fLx_lb.append(solve_fLx_lb(p, f, L, H, h, k)) # solving for the the lower-bound of (f-Lx)

                theta_ub_2 = solve_theta_ub_2(obj_ub, fLx_lb, m, n, 0)  # solving for the upper-bounds of theta^(2)

                theta_ub = [] # solving and storing the upper-bounds of dual variables
                for k in range(m-n):
                    theta_ub.append(solve_theta_ub_1(obj_ub, fLx_lb, m, n, k))
                for k in range(n):
                    theta_ub.append(theta_ub_2)

                theta_lb = [] # storing the lower-bounds of dual variables
                for k in range(m):
                    theta_lb.append(0)
                    
                time_theta = time.time() - start_time

                # Solve for the upper- and lower-bound of sum_k(L_ki*theta_k). 
                
                start_time = time.time()

                L_theta_ub = []
                for i in range(q):
                    L_theta_ub.append(solve_L_theta_ub(obj_ub, fLx_lb, m, n, L, i))
                    
                L_theta_lb = []
                for i in range(q):
                    L_theta_lb.append(0)

                time_L_theta = time.time() - start_time

                # Solve for M and M_tilde.
                
                start_time = time.time()
                
                M = []
                for k in range(m):
                    M.append(theta_ub[k])
                for k in range(m):
                    M.append(f[k])
                M = math.ceil(max(M))
                
                time_M = time.time() - start_time
                
                start_time = time.time()
                
                M_tilde = [1]
                for j in range(n):
                    M_tilde.append(sum(F[i][j]*theta_ub[i] for i in range(m)) - c[j])
                M_tilde = math.ceil(max(M_tilde))
                
                time_M_tilde = time.time() - start_time
                
                time_R1 = time_theta + time_M + time_M_tilde
                time_L2 = time_theta
                time_L3 = time_theta + time_L_theta
                
                big_M = {"obj_ub": obj_ub, "fLx_lb": fLx_lb, "theta_ub": theta_ub, "theta_lb": theta_lb, "M": M, "M_tilde": M_tilde, "L_theta_ub": L_theta_ub, "L_theta_lb": L_theta_lb, "t_theta": time_theta, "t_M": time_M, "t_M_tilde": time_M_tilde, "t_L_theta": time_L_theta, "t_R1": time_R1, "t_L2": time_L2, "t_L3": time_L3}

                # Compare SOS, BL, R1, L2, L3 to solve the problem. 
                
                sol_SOS = solve_SOS(q_1, q_2, n, p, m, a, c, d, H, h, F, L, f)
                sol_BL = solve_BL(q_1, q_2, n, p, m, a, c, d, H, h, F, L, f)

                sol_R1 = solve_R1(M, M_tilde, time_R1, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f)
                sol_R1_LP = solve_R1_LP(M, M_tilde, time_R1, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f)
                
                sol_L2 = solve_L2(theta_ub, theta_lb, time_L2, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, T)
                sol_L2_LP = solve_L2_LP(theta_ub, theta_lb, time_L2, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, T)

                sol_L3 = solve_L3(L_theta_ub, L_theta_lb, time_L3, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, T)
                sol_L3_LP = solve_L3_LP(L_theta_ub, L_theta_lb, time_L3, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, T)
                
                # Save solutions into a .json file.

                sol["SOS"] = sol_SOS
                sol["BL"] = sol_BL

                sol["R1"] = sol_R1
                sol["R1_LP"] = sol_R1_LP
                
                sol["L2"] = sol_L2
                sol["L2_LP"] = sol_L2_LP
                    
                sol["L3"] = sol_L3
                sol["L3_LP"] = sol_L3_LP
                
                multiple_sol[count] = sol
                multiple_big_M[count] = big_M
                
                sol_storage_T[size] = multiple_sol
                big_M_storage_T[size] = multiple_big_M

                sol_storage[num_T] = sol_storage_T
                big_M_storage[num_T] = big_M_storage_T
                
                # Save test instances and results into a json file.
                
                json_path = os.getcwd()
                file_name = 'BBLIP_test_results.json'
                fname = os.path.join(json_path, file_name)
                
                with open(fname, 'w') as json_file:
                    json.dump(sol_storage, json_file, indent=4)

                json_path = os.getcwd()
                file_name = 'BBLIP_big_M.json'
                fname = os.path.join(json_path, file_name)
                
                with open(fname, 'w') as json_file:
                    json.dump(big_M_storage, json_file, indent=4)