## Import packages.

import numpy as np # to generate random instances
import math # to calculate floor and ceiling

import os  # to specify file path
import json # to save instances as .json file

## Bounded Bilevel Linear Integer Problem (BBLIP) ##

## Design different sizes for the random instances.

q_1_list = []
q_2_list = []
n_list = []
p_list = []
m_list = []

for num_q_1 in range(1):
    for num_q_2 in range(3):
        for num_n in range(3):
            for num_p in range(1):
                for num_m_ in range(2): 
                    q_1_list.append(10 + 5*num_q_1)
                    q_2_list.append(1 + 2*num_q_2)
                    n_list.append(50 + 25*num_n)
                    p_list.append(1)
                    m_list.append(15 + 10*num_m_)


## Generate random test instances for BBLIP.

inst_storage = dict()

for size in range(len(n_list)):
    
    # Specify problem size.

    q_1 = q_1_list[size]
    q_2 = q_2_list[size]
    q = q_1 + q_2
    
    n = n_list[size]
    p = p_list[size]
    m_ = m_list[size]

    # Generate multiple instances for each size.

    multiple_inst = dict()

    for count in range(10):

        # Generate random test instances for BBLIP.

        a = np.random.randint(1,100,(q))
        c = np.random.randint(1,100,(n))
        d = np.random.randint(1,100,(n))

        H = np.random.randint(1,100,(p,q))
        h = []
        for l in range(p):
            h.append(math.floor(0.75*sum(H[l][i] for i in range(q))))

        F_ = np.random.randint(1,100,(m_,n))
        L_ = np.random.randint(1,100,(m_,q))
        f_ = []
        for k in range(m_):
            f_.append(math.floor(0.25*(sum(L_[k][i] for i in range(q)) + sum(F_[k][j] for j in range(n)))))

        # Convert BBLIP parameters to parameters in the generic BP.

        m = m_+n

        F = []
        for k in range(m_):
            F.append(F_[k])
        for j in range(n):
            row = np.zeros(n)
            row[j] = 1
            F.append(row)

        L = []
        for k in range(m_):
            L.append(L_[k])
        for j in range(n):
            row = np.zeros(q)
            L.append(row)

        f = []
        for k in range(m_):
            f.append(f_[k])
        for j in range(n):
            f.append(1)

        # Store test instances from numpy to list.

        a = np.array(a).tolist()
        c = np.array(c).tolist()
        d = np.array(d).tolist()
        H = np.array(H).tolist()
        h = np.array(h).tolist()
        F = np.array(F).tolist()
        L = np.array(L).tolist()
        f = np.array(f).tolist()
        F_ = np.array(F_).tolist()
        L_ = np.array(L_).tolist()
        f_ = np.array(f_).tolist()

        inst = {"p": p, "q_1": q_1, "q_2": q_2, "q": q, "m": m, "n": n, "a": a, "c": c, "d": d, "H": H, "h": h, "F": F, "L": L, "f": f, "F_": F_, "L_": L_, "f_": f_}

        multiple_inst[count] = inst

        inst_storage[size] = multiple_inst

## Save test instances into a json file.

json_path = os.getcwd()
file_name = 'BBLIP_instances.json'
fname = os.path.join(json_path, file_name)

with open(fname, 'w') as json_file:
    json.dump(inst_storage, json_file, indent=4)