## Import packages.

import gurobipy as gp
from gurobipy import GRB

import os, json, math, time
from pathlib import Path

# Gurobi WLS license.

options = {
    "WLSACCESSID": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
    "WLSSECRET":   "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
    "LICENSEID":   xxxxxxx
}

# Preset model parameters.

value_LogToConsole = 0
value_LogToConsole_LP = 0
value_LogToConsole_big_M = 0

value_FeasibilityTol = 1e-6
value_FeasibilityTol_LP = 1e-6
value_FeasibilityTol_big_M = 1e-6

value_IntFeasTol = 1e-5
value_IntFeasTol_LP = 1e-5
value_IntFeasTol_big_M = 1e-5

value_Timelimit = 3600
value_Timelimit_LP = 3600
value_Timelimit_big_M = 3600

## Define functions solving the BBLIP under reformulation R1.

# Solve the problem under R1.

def solve_R1(M, M_tilde, t_R1, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f):

    with gp.Model(env=env) as model:
    
        start_time = time.time()
        
        x = model.addVars(q_1, vtype=GRB.BINARY, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta") 
        
        u = model.addVars(m, vtype=GRB.BINARY, name="u")
        v = model.addVars(n, vtype=GRB.BINARY, name="v")
        
        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))
        
        model.addConstrs(f[j] - sum(F[j][i]*y[i] for i in range(n)) - sum(L[j][i]*x[i] for i in range(q_1)) - sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= M*u[j] for j in range(m))
        model.addConstrs(theta[i] <= M*(1-u[i]) for i in range(m))
        
        model.addConstrs(sum(F[i][j]*theta[i] for i in range(m)) - c[j] <= M_tilde*v[j] for j in range(n))
        model.addConstrs(y[i] <= M_tilde*(1-v[i]) for i in range(n))
        
        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    
        
        model.setParam('LogToConsole', value_LogToConsole)
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()
        
        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            gap = model.getAttr("MIPGap")
            return dict(optval=float('nan'), solution=float('nan'), gap=gap, time=end_time+t_R1)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            gap = model.getAttr("MIPGap")
            return dict(optval=optval, solution=solution, gap=gap, time=end_time+t_R1)

# Solve the LP problem under R1.

def solve_R1_LP(M, M_tilde, t_R1, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f):

    with gp.Model(env=env) as model:

        start_time = time.time()

        x = model.addVars(q_1, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta") 
        
        u = model.addVars(m, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="u")
        v = model.addVars(n, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="v")
        
        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))
        
        model.addConstrs(f[j] - sum(F[j][i]*y[i] for i in range(n)) - sum(L[j][i]*x[i] for i in range(q_1)) - sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= M*u[j] for j in range(m))
        model.addConstrs(theta[i] <= M*(1-u[i]) for i in range(m))
        
        model.addConstrs(sum(F[i][j]*theta[i] for i in range(m)) - c[j] <= M_tilde*v[j] for j in range(n))
        model.addConstrs(y[i] <= M_tilde*(1-v[i]) for i in range(n))
        
        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    
        
        model.setParam('LogToConsole', value_LogToConsole)
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()

        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            return dict(optval=float('nan'), solution=float('nan'), time=end_time+t_R1)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            return dict(optval=optval, solution=solution, time=end_time+t_R1)
    
## Define functions solving the BBLIP under reformulation L2.

# Solve the problem under L2.

def solve_L2(theta_ub, theta_lb, t_L2, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, T):

    with gp.Model(env=env) as model:

        start_time = time.time()

        x = model.addVars(q_1, vtype=GRB.BINARY, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta") 

        v = model.addVars(q_1, m, vtype=GRB.CONTINUOUS, name="v")
        z = model.addVars(q_2, T, vtype=GRB.BINARY, name="z")
        u = model.addVars(q_2, m, T, vtype=GRB.CONTINUOUS, name="u")

        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))

        model.addConstrs(v[i,k] <= theta_ub[k]*x[i] for i in range(q_1) for k in range(m))
        model.addConstrs(v[i,k] <= theta[k] + theta_lb[k]*x[i] - theta_lb[k] for i in range(q_1) for k in range(m))
        model.addConstrs(v[i,k] >= theta_lb[k]*x[i] for i in range(q_1) for k in range(m))
        model.addConstrs(v[i,k] >= theta[k] + theta_ub[k]*x[i] - theta_ub[k] for i in range(q_1) for k in range(m))

        model.addConstrs(u[i,k,t] <= theta_ub[k]*z[i,t] for t in range(T) for i in range(q_2) for k in range(m))
        model.addConstrs(u[i,k,t] <= theta[k] + theta_lb[k]*z[i,t] - theta_lb[k] for t in range(T) for i in range(q_2) for k in range(m))
        model.addConstrs(u[i,k,t] >= theta_lb[k]*z[i,t] for i in range(q_2) for t in range(T) for k in range(m))
        model.addConstrs(u[i,k,t] >= theta[k] + theta_ub[k]*z[i,t] - theta_ub[k] for t in range(T) for i in range(q_2) for k in range(m))

        model.addConstrs(x_c[i] == sum(2**(-t)*z[i,t] for t in range(T)) for i in range(q_2))
        model.addConstr(sum(c[i]*y[i] for i in range(n)) + sum(L[k][i]*v[i,k] for i in range(q_1) for k in range(m)) + sum(2**(-t)*L[k][q_1+i]*u[i,k,t] for t in range(T) for i in range(q_2) for k in range(m)) == sum(f[i]*theta[i] for i in range(m)))

        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    

        model.setParam('LogToConsole', value_LogToConsole)
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()
        
        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            gap = model.getAttr("MIPGap")
            return dict(optval=float('nan'), solution=float('nan'), gap=gap, time=end_time+t_L2)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            gap = model.getAttr("MIPGap")
            return dict(optval=optval, solution=solution, gap=gap, time=end_time+t_L2)

# Solve the LP problem under L2.

def solve_L2_LP(theta_ub, theta_lb, t_L2, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, T):

    with gp.Model(env=env) as model:

        start_time = time.time()
  
        x = model.addVars(q_1, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta") 

        v = model.addVars(q_1, m, vtype=GRB.CONTINUOUS, name="v")
        z = model.addVars(q_2, T, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="z")
        u = model.addVars(q_2, m, T, vtype=GRB.CONTINUOUS, name="u")


        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))

        model.addConstrs(v[i,k] <= theta_ub[k]*x[i] for i in range(q_1) for k in range(m))
        model.addConstrs(v[i,k] <= theta[k] + theta_lb[k]*x[i] - theta_lb[k] for i in range(q_1) for k in range(m))
        model.addConstrs(v[i,k] >= theta_lb[k]*x[i] for i in range(q_1) for k in range(m))
        model.addConstrs(v[i,k] >= theta[k] + theta_ub[k]*x[i] - theta_ub[k] for i in range(q_1) for k in range(m))

        model.addConstrs(u[i,k,t] <= theta_ub[k]*z[i,t] for t in range(T) for i in range(q_2) for k in range(m))
        model.addConstrs(u[i,k,t] <= theta[k] + theta_lb[k]*z[i,t] - theta_lb[k] for t in range(T) for i in range(q_2) for k in range(m))
        model.addConstrs(u[i,k,t] >= theta_lb[k]*z[i,t] for i in range(q_2) for t in range(T) for k in range(m))
        model.addConstrs(u[i,k,t] >= theta[k] + theta_ub[k]*z[i,t] - theta_ub[k] for t in range(T) for i in range(q_2) for k in range(m))

        model.addConstrs(x_c[i] == sum(2**(-t)*z[i,t] for t in range(T)) for i in range(q_2))
        model.addConstr(sum(c[i]*y[i] for i in range(n)) + sum(L[k][i]*v[i,k] for i in range(q_1) for k in range(m)) + sum(2**(-t)*L[k][q_1+i]*u[i,k,t] for t in range(T) for i in range(q_2) for k in range(m)) == sum(f[i]*theta[i] for i in range(m)))

        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    

        model.setParam('LogToConsole', value_LogToConsole)
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()
        
        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            return dict(optval=float('nan'), solution=float('nan'), time=end_time+t_L2)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            return dict(optval=optval, solution=solution, time=end_time+t_L2)

## Define functions solving the BBLIP under reformulation L3.

# Solve the problem under L3.

def solve_L3(L_theta_ub, L_theta_lb, t_L3, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, T):

    with gp.Model(env=env) as model:

        start_time = time.time()

        x = model.addVars(q_1, vtype=GRB.BINARY, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta") 

        v = model.addVars(q_1, vtype=GRB.CONTINUOUS, name="v")
        z = model.addVars(q_2, T, vtype=GRB.BINARY, name="z")
        u = model.addVars(q_2, T, vtype=GRB.CONTINUOUS, name="u")

        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))

        model.addConstrs(v[i] <= L_theta_ub[i]*x[i] for i in range(q_1))
        model.addConstrs(v[i] <= sum(L[k][i]*theta[k] for k in range(m)) + L_theta_lb[i]*x[i] - L_theta_lb[i] for i in range(q_1))
        model.addConstrs(v[i] >= L_theta_lb[i]*x[i] for i in range(q_1))
        model.addConstrs(v[i] >= sum(L[k][i]*theta[k] for k in range(m)) + L_theta_ub[i]*x[i] - L_theta_ub[i] for i in range(q_1))

        model.addConstrs(u[i,t] <= L_theta_ub[q_1+i]*z[i,t] for t in range(T) for i in range(q_2))
        model.addConstrs(u[i,t] <= sum(L[k][q_1+i]*theta[k] for k in range(m)) + L_theta_lb[q_1+i]*z[i,t] - L_theta_lb[q_1+i] for t in range(T) for i in range(q_2))
        model.addConstrs(u[i,t] >= L_theta_lb[q_1+i]*z[i,t] for i in range(q_2) for t in range(T))
        model.addConstrs(u[i,t] >= sum(L[k][q_1+i]*theta[k] for k in range(m)) + L_theta_ub[q_1+i]*z[i,t] - L_theta_ub[q_1+i] for t in range(T) for i in range(q_2))

        model.addConstrs(x_c[i] == sum(2**(-t)*z[i,t] for t in range(T)) for i in range(q_2))
        model.addConstr(sum(c[i]*y[i] for i in range(n)) + sum(v[i] for i in range(q_1)) + sum(2**(-t)*u[i,t] for t in range(T) for i in range(q_2)) == sum(f[i]*theta[i] for i in range(m)))

        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    

        model.setParam('LogToConsole', value_LogToConsole)
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()
        
        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            gap = model.getAttr("MIPGap")
            return dict(optval=float('nan'), solution=float('nan'), gap=gap, time=end_time+t_L3)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            gap = model.getAttr("MIPGap")
            return dict(optval=optval, solution=solution, gap=gap, time=end_time+t_L3)

# Solve the LP problem under L3.

def solve_L3_LP(L_theta_ub, L_theta_lb, t_L3, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, T):

    with gp.Model(env=env) as model:

        start_time = time.time()

        x = model.addVars(q_1, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta")  

        v = model.addVars(q_1, vtype=GRB.CONTINUOUS, name="v")
        z = model.addVars(q_2, T, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="z")
        u = model.addVars(q_2, T, vtype=GRB.CONTINUOUS, name="u")

        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))

        model.addConstrs(v[i] <= L_theta_ub[i]*x[i] for i in range(q_1))
        model.addConstrs(v[i] <= sum(L[k][i]*theta[k] for k in range(m)) + L_theta_lb[i]*x[i] - L_theta_lb[i] for i in range(q_1))
        model.addConstrs(v[i] >= L_theta_lb[i]*x[i] for i in range(q_1))
        model.addConstrs(v[i] >= sum(L[k][i]*theta[k] for k in range(m)) + L_theta_ub[i]*x[i] - L_theta_ub[i] for i in range(q_1))

        model.addConstrs(u[i,t] <= L_theta_ub[q_1+i]*z[i,t] for t in range(T) for i in range(q_2))
        model.addConstrs(u[i,t] <= sum(L[k][q_1+i]*theta[k] for k in range(m)) + L_theta_lb[q_1+i]*z[i,t] - L_theta_lb[q_1+i] for t in range(T) for i in range(q_2))
        model.addConstrs(u[i,t] >= L_theta_lb[q_1+i]*z[i,t] for i in range(q_2) for t in range(T))
        model.addConstrs(u[i,t] >= sum(L[k][q_1+i]*theta[k] for k in range(m)) + L_theta_ub[q_1+i]*z[i,t] - L_theta_ub[q_1+i] for t in range(T) for i in range(q_2))

        model.addConstrs(x_c[i] == sum(2**(-t)*z[i,t] for t in range(T)) for i in range(q_2))
        model.addConstr(sum(c[i]*y[i] for i in range(n)) + sum(v[i] for i in range(q_1)) + sum(2**(-t)*u[i,t] for t in range(T) for i in range(q_2)) == sum(f[i]*theta[i] for i in range(m)))

        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    

        model.setParam('LogToConsole', value_LogToConsole)
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()
        
        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            return dict(optval=float('nan'), solution=float('nan'), time=end_time+t_L3)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            return dict(optval=optval, solution=solution, time=end_time+t_L3)
     
## Define functions solving the BBLIP using CS-based approach with SOS1 constraints.

# Solve the problem using CS-based approach.

def solve_SOS(q_1, q_2, n, p, m, a, c, d, H, h, F, L, f):

    with gp.Model(env=env) as model:
    
        start_time = time.time()
        
        x = model.addVars(q_1, vtype=GRB.BINARY, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta") 
        
        u = model.addVars(m, vtype=GRB.CONTINUOUS, name="u")
        v = model.addVars(n, vtype=GRB.CONTINUOUS, name="v")
        
        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))

        model.addConstrs(u[j] == f[j] - sum(F[j][i]*y[i] for i in range(n)) - sum(L[j][i]*x[i] for i in range(q_1)) - sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) for j in range(m))
        for j in range(m):
            model.addSOS(GRB.SOS_TYPE1, [u[j], theta[j]], [1, 2])

        model.addConstrs(v[j] == sum(F[i][j]*theta[i] for i in range(m)) - c[j] for j in range(n))
        for j in range(n):
            model.addSOS(GRB.SOS_TYPE1, [v[j], y[j]], [1, 2])

        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    
        
        model.setParam('LogToConsole', value_LogToConsole)
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()
        
        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            gap = model.getAttr("MIPGap")
            return dict(optval=float('nan'), solution=float('nan'), gap=gap, time=end_time)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            gap = model.getAttr("MIPGap")
            return dict(optval=optval, solution=solution, gap=gap, time=end_time)
    
## Define functions solving the BBLIP using SD-based approach with bilinear constraints.

# Solve the problem using SD-based approach.

def solve_BL(q_1, q_2, n, p, m, a, c, d, H, h, F, L, f):

    with gp.Model(env=env) as model:

        start_time = time.time()
 
        x = model.addVars(q_1, vtype=GRB.BINARY, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta") 

        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))

        model.addConstr(sum(c[i]*y[i] for i in range(n)) == sum(f[i]*theta[i] for i in range(m)) - sum(L[k][i]*theta[k]*x[i] for i in range(q_1) for k in range(m)) - sum(L[k][q_1+i]*theta[k]*x_c[i] for i in range(q_2) for k in range(m)))

        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    

        model.setParam('LogToConsole', value_LogToConsole)
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()
        
        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            gap = model.getAttr("MIPGap")
            return dict(optval=float('nan'), solution=float('nan'), gap=gap, time=end_time)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            gap = model.getAttr("MIPGap")
            return dict(optval=optval, solution=solution, gap=gap, time=end_time)

## Load data and run all formulations.

# Paths.

ROOT = Path.cwd() 
INST_FILE   = ROOT / "BBLIP_instances.json"       
BOUNDS_FILE = ROOT / "BBLIP_bounds.json"    

# Load instances.

instances = json.loads(INST_FILE.read_text(encoding="utf-8"))

# Load bounds.

bounds = json.loads(BOUNDS_FILE.read_text(encoding="utf-8"))

sol_storage = dict()

with gp.Env(params=options) as env:

    for size in range(len(instances)):

        multiple_sol = dict()

        for count in range(len(instances[str(size)])):
            
            # Prepare random test instances for BBLIP parameters.
            
            p = instances[str(size)][str(count)]["p"]
            q_1 = instances[str(size)][str(count)]["q_1"]
            q_2 = instances[str(size)][str(count)]["q_2"]
            q = q_1 + q_2
            m = instances[str(size)][str(count)]["m"]
            n = instances[str(size)][str(count)]["n"]
            a = instances[str(size)][str(count)]["a"]
            c = instances[str(size)][str(count)]["c"]
            d = instances[str(size)][str(count)]["d"]
            H = instances[str(size)][str(count)]["H"]
            h = instances[str(size)][str(count)]["h"]
            F = instances[str(size)][str(count)]["F"]
            L = instances[str(size)][str(count)]["L"]
            f = instances[str(size)][str(count)]["f"]

            sol = {"p": p, "q_1": q_1, "q_2": q_2, "q": q, "m": m, "n": n, "a": a, "c": c, "d": d, "H": H, "h": h, "F": F, "L": L, "f": f}

            M = bounds[str(size)][str(count)]["M"]
            M_tilde = bounds[str(size)][str(count)]["M_tilde"]
            theta_ub = bounds[str(size)][str(count)]["theta_ub"]
            theta_lb = bounds[str(size)][str(count)]["theta_lb"]
            L_theta_ub = bounds[str(size)][str(count)]["L_theta_ub"]
            L_theta_lb = bounds[str(size)][str(count)]["L_theta_lb"]
            time_R1 = bounds[str(size)][str(count)]["t_R1"]
            time_L2 = bounds[str(size)][str(count)]["t_L2"]
            time_L3 = bounds[str(size)][str(count)]["t_L3"]

            # Compare SOS, BL, R1, L2, L3 to solve the problem. 
            
            sol_SOS = solve_SOS(q_1, q_2, n, p, m, a, c, d, H, h, F, L, f)
            sol_BL = solve_BL(q_1, q_2, n, p, m, a, c, d, H, h, F, L, f)
            sol_R1 = solve_R1(M, M_tilde, time_R1, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f)
            sol_R1_LP = solve_R1_LP(M, M_tilde, time_R1, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f)

            sol_L2_T4 = solve_L2(theta_ub, theta_lb, time_L2, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, 4)
            sol_L2_T4_LP = solve_L2_LP(theta_ub, theta_lb, time_L2, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, 4)
            sol_L3_T4 = solve_L3(L_theta_ub, L_theta_lb, time_L3, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, 4)
            sol_L3_T4_LP = solve_L3_LP(L_theta_ub, L_theta_lb, time_L3, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, 4)

            sol_L2_T7 = solve_L2(theta_ub, theta_lb, time_L2, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, 7)
            sol_L2_T7_LP = solve_L2_LP(theta_ub, theta_lb, time_L2, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, 7)
            sol_L3_T7 = solve_L3(L_theta_ub, L_theta_lb, time_L3, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, 7)
            sol_L3_T7_LP = solve_L3_LP(L_theta_ub, L_theta_lb, time_L3, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, 7)
        
            # Save solutions into a .json file.

            sol["SOS"] = sol_SOS
            sol["BL"] = sol_BL
            sol["R1"] = sol_R1
            sol["R1_LP"] = sol_R1_LP
            
            sol["L2_T4"] = sol_L2_T4
            sol["L2_T4_LP"] = sol_L2_T4_LP
            sol["L3_T4"] = sol_L3_T4
            sol["L3_T4_LP"] = sol_L3_T4_LP

            sol["L2_T7"] = sol_L2_T7
            sol["L2_T7_LP"] = sol_L2_T7_LP
            sol["L3_T7"] = sol_L3_T7
            sol["L3_T7_LP"] = sol_L3_T7_LP
            
            multiple_sol[count] = sol      
            sol_storage[size] = multiple_sol
            
            # Save test instances and results into a json file.
            
            json_path = os.getcwd()
            file_name = 'BBLIP_results.json'
            fname = os.path.join(json_path, file_name)
            
            with open(fname, 'w') as json_file:
                json.dump(sol_storage, json_file, indent=4)