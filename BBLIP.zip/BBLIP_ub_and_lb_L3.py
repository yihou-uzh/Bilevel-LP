## Import packages.

import gurobipy as gp
from gurobipy import GRB

import math
import time

import os
import json

options = {
    "WLSACCESSID": "365c04ea-c99c-4a13-a235-6b1e7a34f04c",
    "WLSSECRET":   "d461a18b-647a-43aa-a70a-7e3b94e21296",
    "LICENSEID":   2458765
}

## Adjust Gurobi model parameters.

# Specify whether to enables console logging (=1 enable, =0 disable).

value_LogToConsole = 0
value_LogToConsole_LP = 0
value_LogToConsole_big_M = 0

# Specify the primal feasibility tolerance (=1e-6 default, =1e-9 minimum, =1e-2 maximum).

value_FeasibilityTol = 1e-6
value_FeasibilityTol_LP = 1e-6
value_FeasibilityTol_big_M = 1e-6

# Specify the integer feasibility tolerance (=1e-5 default, =1e-9 minimum, =1e-1 maximum).

value_IntFeasTol = 1e-5
value_IntFeasTol_LP = 1e-5
value_IntFeasTol_big_M = 1e-5

# Specify the limits the total time expended (in seconds) (=Infinity default, =0 minimum, =Infinity maximum).

value_Timelimit = 3600
value_Timelimit_LP = 3600
value_Timelimit_big_M = 3600

# Specify the number of current jobs.

value_ConcurrentJobs = 0

# Specify the number of threads.

value_Threads = 8

## Define functions solving the BBLIP under relaxed Reformulation 3 (with McCormick Envelopes) to obtain an upper-bound (U3).

# Solve the problem under U3.

def solve_U3(L_theta_ub, L_theta_lb, t_L3, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, T):

    with gp.Model(env=env) as model:

        start_time = time.time()

        x = model.addVars(q_1, vtype=GRB.BINARY, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta") 

        v = model.addVars(q_1, vtype=GRB.CONTINUOUS, name="v")
        z = model.addVars(q_2, T, vtype=GRB.BINARY, name="z")
        u = model.addVars(q_2, T, vtype=GRB.CONTINUOUS, name="u")

        est = model.addVars(q_2, lb=0, ub=2**(-T), vtype=GRB.CONTINUOUS, name="epsilon")
        w = model.addVars(q_2, vtype=GRB.CONTINUOUS, name="w")

        model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))

        model.addConstrs(v[i] <= L_theta_ub[i]*x[i] for i in range(q_1))
        model.addConstrs(v[i] <= sum(L[k][i]*theta[k] for k in range(m)) + L_theta_lb[i]*x[i] - L_theta_lb[i] for i in range(q_1))
        model.addConstrs(v[i] >= L_theta_lb[i]*x[i] for i in range(q_1))
        model.addConstrs(v[i] >= sum(L[k][i]*theta[k] for k in range(m)) + L_theta_ub[i]*x[i] - L_theta_ub[i] for i in range(q_1))

        model.addConstrs(u[i,t] <= L_theta_ub[q_1+i]*z[i,t] for t in range(T) for i in range(q_2))
        model.addConstrs(u[i,t] <= sum(L[k][q_1+i]*theta[k] for k in range(m)) + L_theta_lb[q_1+i]*z[i,t] - L_theta_lb[q_1+i] for t in range(T) for i in range(q_2))
        model.addConstrs(u[i,t] >= L_theta_lb[q_1+i]*z[i,t] for i in range(q_2) for t in range(T))
        model.addConstrs(u[i,t] >= sum(L[k][q_1+i]*theta[k] for k in range(m)) + L_theta_ub[q_1+i]*z[i,t] - L_theta_ub[q_1+i] for t in range(T) for i in range(q_2))

        model.addConstrs(w[i] <= L_theta_ub[q_1+i]*est[i] for i in range(q_2))
        model.addConstrs(w[i] <= sum(L[k][q_1+i]*theta[k] for k in range(m))*2**(-T) + L_theta_lb[q_1+i]*est[i] - L_theta_lb[q_1+i]*2**(-T) for i in range(q_2))
        model.addConstrs(w[i] >= L_theta_lb[q_1+i]*est[i] for i in range(q_2))
        model.addConstrs(w[i] >= sum(L[k][q_1+i]*theta[k] for k in range(m))*2**(-T) + L_theta_ub[q_1+i]*est[i] - L_theta_ub[q_1+i]*2**(-T) for i in range(q_2))
              
        model.addConstrs(x_c[i] == sum(2**(-t)*z[i,t] for t in range(T)) + est[i] for i in range(q_2))
        model.addConstr(sum(c[i]*y[i] for i in range(n)) + sum(v[i] for i in range(q_1)) + sum(2**(-t)*u[i,t] for t in range(T) for i in range(q_2)) + sum(w[i] for i in range(q_2)) == sum(f[i]*theta[i] for i in range(m)))

        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    

        model.Params.LogToConsole = value_LogToConsole
        model.Params.ConcurrentJobs = value_ConcurrentJobs
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()
        
        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            gap = model.getAttr("MIPGap")
            return dict(optval=float('nan'), solution=float('nan'), gap=gap, time=end_time+t_L3)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            gap = model.getAttr("MIPGap")
            return dict(optval=optval, solution=solution, gap=gap, time=end_time+t_L3)
        
## Define functions solving the BBLIP under Reformulation 3 using predetermined x, x_c values to obtain a lower-bound (LU3).

# Solve the problem under LU3.

def solve_LU3(q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, T, x, x_c):

    with gp.Model(env=env) as model:

        start_time = time.time()

        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y") 
        theta = model.addVars(m, lb=0, vtype=GRB.CONTINUOUS, name="theta") 

        # model.addConstrs(sum(H[j][i]*x[i] for i in range(q_1)) + sum(H[j][q_1+i]*x_c[i] for i in range(q_2)) <= h[j] for j in range(p))
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m))
        model.addConstrs(-sum(F[i][j]*theta[i] for i in range(m)) <= -c[j] for j in range(n))

        model.addConstr(sum(c[i]*y[i] for i in range(n)) + sum(L[k][i]*theta[k]*x[i] for i in range(q_1) for k in range(m)) + sum(L[k][q_1+i]*theta[k]*x_c[i] for i in range(q_2) for k in range(m)) == sum(f[i]*theta[i] for i in range(m)))

        model.setObjective(sum(a[i]*x[i] for i in range(q_1)) + sum(a[q_1+i]*x_c[i] for i in range(q_2)) +  sum(d[i]*y[i] for i in range(n)), GRB.MAXIMIZE)    

        model.Params.LogToConsole = value_LogToConsole
        model.Params.ConcurrentJobs = value_ConcurrentJobs
        model.setParam('FeasibilityTol', value_FeasibilityTol)
        model.setParam('IntFeasTol', value_IntFeasTol)
        model.setParam('Timelimit', value_Timelimit)
        model.optimize()
        
        end_time = time.time() - start_time

        if model.getAttr("SolCount") == 0:
            return dict(optval=float('nan'), solution=float('nan'), time=end_time)
        else:
            optval = model.getAttr("ObjVal")
            solution = model.getAttr("X")
            return dict(optval=optval, solution=solution, time=end_time)
        
## Bounded Bilevel Linear Integer Problem (BBLIP) ##

## Import test instances from .json file.

json_path = os.getcwd()
file_name = 'BBLIP_test_instances.json'
fname = os.path.join(json_path, file_name)

# Open .json file.
file = open(fname) 
 
# Return .json object as a dictionary.
inst_storage = json.load(file)

# Close .json file.
file.close()

## Import big-M results from .json file.

json_path = os.getcwd()
file_name = 'BBLIP_big_M.json'
fname = os.path.join(json_path, file_name)

# Open .json file.
file = open(fname) 
 
# Return .json object as a dictionary.
big_M_storage = json.load(file)

# Close .json file.
file.close()

## Run experiments with random test instances of the different sizes.

sol_storage = dict()

with gp.Env(params=options) as env:

    for num_T in range(2):

        sol_storage_T = dict()

        T = 4 + 3*num_T

        for size in range(len(inst_storage[str(num_T)])):

            multiple_sol = dict()

            for count in range(len(inst_storage[str(num_T)][str(size)])):
                
                # Prepare random test instances for BBLIP parameters.
                
                p = inst_storage[str(num_T)][str(size)][str(count)]["p"]
                q_1 = inst_storage[str(num_T)][str(size)][str(count)]["q_1"]
                q_2 = inst_storage[str(num_T)][str(size)][str(count)]["q_2"]
                q = q_1 + q_2
                m = inst_storage[str(num_T)][str(size)][str(count)]["m"]
                n = inst_storage[str(num_T)][str(size)][str(count)]["n"]
                a = inst_storage[str(num_T)][str(size)][str(count)]["a"]
                c = inst_storage[str(num_T)][str(size)][str(count)]["c"]
                d = inst_storage[str(num_T)][str(size)][str(count)]["d"]
                H = inst_storage[str(num_T)][str(size)][str(count)]["H"]
                h = inst_storage[str(num_T)][str(size)][str(count)]["h"]
                F = inst_storage[str(num_T)][str(size)][str(count)]["F"]
                L = inst_storage[str(num_T)][str(size)][str(count)]["L"]
                f = inst_storage[str(num_T)][str(size)][str(count)]["f"]

                sol = {"p": p, "q_1": q_1, "q_2": q_2, "q": q, "m": m, "n": n, "a": a, "c": c, "d": d, "H": H, "h": h, "F": F, "L": L, "f": f, "T": T}

                L_theta_ub = big_M_storage[str(num_T)][str(size)][str(count)]["L_theta_ub"]
                L_theta_lb = big_M_storage[str(num_T)][str(size)][str(count)]["L_theta_lb"]
                t_L3 = big_M_storage[str(num_T)][str(size)][str(count)]["t_L3"]

                # Compare L3, U3, LU3 to solve the problem.

                sol_U3 = solve_U3(L_theta_ub, L_theta_lb, t_L3, q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, T)

                x_U3 = sol_U3["solution"][:q_1]
                x_c_U3 = sol_U3["solution"][q_1:q_1+q_2]

                sol_LU3 = solve_LU3(q_1, q_2, n, p, m, a, c, d, H, h, F, L, f, T, x_U3, x_c_U3)
                
                # Save solutions into a .json file.

                sol["U3"] = sol_U3
                sol["LU3"] = sol_LU3
                
                multiple_sol[count] = sol
                sol_storage_T[size] = multiple_sol
                sol_storage[num_T] = sol_storage_T
                
                # Save test instances and results into a json file.
                
                json_path = os.getcwd()
                file_name = 'BBLIP_ub_and_lb_L3.json'
                fname = os.path.join(json_path, file_name)
                
                with open(fname, 'w') as json_file:
                    json.dump(sol_storage, json_file, indent=4)