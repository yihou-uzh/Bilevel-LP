## Import packages.

import numpy as np # to generate random instances
import math # to calculate floor and ceiling

import os  # to specify file path
import json # to save instances as .json file

## Multidimensional Knapsack Interdiction Problem (MKIP) ##

## Design different sizes for the random instances.

n_list = []
q_1_list = []
q_2_list = []
p_list = []
m_list = []
alpha_list = []

for num_n in [200, 300]: #for num_n in [100, 250, 500]:
    for num_q_1 in [0.9, 0.8, 0.7]:
        for num_m in [10, 30]:
            for num_alpha in [0.25]: #for num_alpha in [0.25, 0.5, 0.75]:
                n_list.append(num_n)
                q_1_list.append(0.1*num_n*num_q_1)
                q_2_list.append(0.1*num_n - 0.1*num_n*num_q_1)
                p_list.append(math.ceil(num_m/2))
                m_list.append(math.ceil(num_m/2))
                alpha_list.append(num_alpha)

## Generate random test instances for MKIP.

inst_storage = dict()

for size in range(len(n_list)):
    
    # Specify problem size.
    
    q_1 = int(q_1_list[size])
    q_2 = int(q_2_list[size])
    q = q_1 + q_2
    
    n = n_list[size]
    p = p_list[size]
    m_ = m_list[size]
    alpha = alpha_list[size]

    # Generate multiple instances for each size.

    multiple_inst = dict()

    for count in range(10):

        # Generate random test instances for MKIP.

        H = np.array(np.random.randint(0,1000,(p,q))).tolist()
        h = [int(alpha*sum(H[l][i] for i in range(q))) for l in range(p)]

        F_ = np.array(np.random.randint(0,1000,(m_,n))).tolist()
        f_ = [int(alpha*sum(F_[k][j] for j in range(n))) for k in range(m_)]

        U = [[1 if i == j else 0 for j in range(n)] for i in range(n)] #U = [[1000 if i == j else 0 for j in range(n)] for i in range(n)]
        group = n // q
        B = [[0]*q for _ in range(n)]
        for j in range(q):
            for i in range(j*group, (j+1)*group):
                B[i][j] = 1

        c = [int(sum(F_[k][j] for k in range(m_))/m_ + 500*np.random.uniform(0,1)) for j in range(n)]

        # Convert MKIP parameters to parameters in the generic BP.

        m = m_+n
        
        a = [0.0]*q
        d = c
        
        F = F_ + [[1 if i == j else 0 for j in range(n)] for i in range(n)]
        L  = [[0]*q for _ in range(m_)] + B #L  = [[0]*q for _ in range(m_)] + [[1000 if B[i][j] == 1 else 0 for j in range(q)] for i in range(n)]
        f = f_ + [1]*n #f = f_ + [1000]*n

        # Store test instances.

        inst = {"p": p, "q_1": q_1, "q_2": q_2, "q": q, "m_": m_, "m": m, "n": n, "alpha": alpha, 
                "a": a, "c": c, "d": d, "H": H, "h": h, "F_": F_, "f_": f_, "U": U, "B": B, "F": F, "L": L, "f": f}

        multiple_inst[count] = inst

        inst_storage[size] = multiple_inst
        
## Save test instances into a json file.

json_path = os.getcwd()
file_name = 'MKIP_instances.json'
fname = os.path.join(json_path, file_name)

with open(fname, 'w') as json_file:
    json.dump(inst_storage, json_file, indent=4)
