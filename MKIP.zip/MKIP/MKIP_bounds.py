## Import packages.

import gurobipy as gp
from gurobipy import GRB

import math
import time

import os
import json

options = {
    "WLSACCESSID": "365c04ea-c99c-4a13-a235-6b1e7a34f04c",
    "WLSSECRET":   "d461a18b-647a-43aa-a70a-7e3b94e21296",
    "LICENSEID":   2458765
}

## Multidimensional Knapsack Interdiction Problem (MKIP) ##

## Define a function solving the upper-bound of dual objective using LP.

def solve_obj_ub(m, n, f, L, c):

    with gp.Model(env=env) as model:
           
        x = model.addVars(q_1, vtype=GRB.BINARY, name="x")
        x_c = model.addVars(q_2, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="x^(c)")
        y = model.addVars(n, lb=0, ub=1, vtype=GRB.CONTINUOUS, name="y")
        
        model.addConstrs( sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i]*x[i] for i in range(q_1)) + sum(L[j][q_1+i]*x_c[i] for i in range(q_2)) <= f[j] for j in range(m-n))
        model.setObjective(sum(c[i]*y[i] for i in range(n)), GRB.MAXIMIZE)
        
        model.setParam('LogToConsole', 0)
        model.optimize()
        
        optval = model.getAttr("ObjVal")
        
        return optval

## Import test instances from .json file.

json_path = os.getcwd()
file_name = 'MKIP_instances.json'
fname = os.path.join(json_path, file_name)

# Open .json file.
file = open(fname) 
 
# Return .json object as a dictionary.
inst_storage = json.load(file)

# Close .json file.
file.close()

## Run experiments with random test instances of the different sizes.

big_M_storage = dict()

with gp.Env(params=options) as env:

    for size in range(len(inst_storage)):

        multiple_big_M = dict()

        for count in range(len(inst_storage[str(size)])):
            
            # Prepare random test instances for MKIP parameters.
            
            p = inst_storage[str(size)][str(count)]["p"]
            q_1 = inst_storage[str(size)][str(count)]["q_1"]
            q_2 = inst_storage[str(size)][str(count)]["q_2"]
            q = q_1 + q_2
            m = inst_storage[str(size)][str(count)]["m"]
            n = inst_storage[str(size)][str(count)]["n"]
            a = inst_storage[str(size)][str(count)]["a"]
            c = inst_storage[str(size)][str(count)]["c"]
            d = inst_storage[str(size)][str(count)]["d"]
            H = inst_storage[str(size)][str(count)]["H"]
            h = inst_storage[str(size)][str(count)]["h"]
            F = inst_storage[str(size)][str(count)]["F"]
            L = inst_storage[str(size)][str(count)]["L"]
            f = inst_storage[str(size)][str(count)]["f"]

            # Solve for the upper- and lower-bound of dual variables theta_k.
            
            start_time = time.time()
            obj_ub = solve_obj_ub(m, n, f, L, c) # solving for the upper-bound of dual objective
            theta_ub = [math.ceil(obj_ub/f[k]) for k in range(m-n)] + [c[k] for k in range(n)]
            theta_lb = [0]*m
            time_theta = time.time() - start_time

            # Solve for the upper- and lower-bound of sum_k(L_ki*theta_k). 
            
            start_time = time.time()
            L_theta_ub = [sum(L[k][i]*theta_ub[k] for k in range(m-n)) + sum(L[m-n+k][i]*theta_ub[m-n+k] for k in range(n)) for i in range(q)]
            L_theta_lb = [0]*q
            time_L_theta = time.time() - start_time + time_theta

            # Solve for M and M_tilde.
            
            start_time = time.time()
            M = [theta_ub[k] for k in range(m)] + [f[k] for k in range(m)]
            M = math.ceil(max(M))
            time_M = time.time() - start_time
            
            start_time = time.time()
            M_tilde = [1] + [sum(F[i][j]*theta_ub[i] for i in range(m)) - c[j] for j in range(n)]
            M_tilde = math.ceil(max(M_tilde))
            time_M_tilde = time.time() - start_time
            
            time_R1 = time_theta + time_M + time_M_tilde
            time_L2 = time_theta
            time_L3 = time_theta + time_L_theta
            
            big_M = {"obj_ub": obj_ub, "theta_ub": theta_ub, "theta_lb": theta_lb, "M": M, "M_tilde": M_tilde, "L_theta_ub": L_theta_ub, "L_theta_lb": L_theta_lb, "t_theta": time_theta, "t_M": time_M, "t_M_tilde": time_M_tilde, "t_L_theta": time_L_theta, "t_R1": time_R1, "t_L2": time_L2, "t_L3": time_L3}

            multiple_big_M[count] = big_M
            big_M_storage[size] = multiple_big_M
            
            # Save big-M into a json file.

            json_path = os.getcwd()
            file_name = 'MKIP_bounds.json'
            fname = os.path.join(json_path, file_name)
            
            with open(fname, 'w') as json_file:
                json.dump(big_M_storage, json_file, indent=4)