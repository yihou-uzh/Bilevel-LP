## Import packages.

import gurobipy as gp
from gurobipy import GRB

import math
import time

import os
import json

options = {
    "WLSACCESSID": "01ce4ba7-e570-471f-8b67-349a63bc3b8b",
    "WLSSECRET":   "e6348df1-5b02-4e2a-aff5-7388789d28c7",
    "LICENSEID":   2709777
}

## Bilevel Linear Integer Problem with Interdiction Constraints (BLIPI) ##

## Define a function solving the upper-bound of dual objective using LP.

def solve_obj_ub(q, n, m, c, F, L, f):

    with gp.Model(env=env) as model:
           
        y = model.addVars(n, lb=0, vtype=GRB.CONTINUOUS, name="y")
        
        model.addConstrs(sum(F[j][i]*y[i] for i in range(n)) + sum(L[j][i] for i in range(q)) <= f[j] for j in range(m))
        model.setObjective(sum(c[i]*y[i] for i in range(n)), GRB.MAXIMIZE)
        
        model.setParam('LogToConsole', 0)
        model.optimize()
        
        optval = model.getAttr("ObjVal")
        
        return optval

## Import test instances from .json file.

json_path = os.getcwd()
file_name = 'BLIPI_instances.json'
fname = os.path.join(json_path, file_name)

# Open .json file.
file = open(fname) 
 
# Return .json object as a dictionary.
inst_storage = json.load(file)

# Close .json file.
file.close()

## Run experiments with random test instances of the different sizes.

big_M_storage = dict()

with gp.Env(params=options) as env:

    for size in range(len(inst_storage)):

        multiple_big_M = dict()

        for count in range(len(inst_storage[str(size)])):
            
            # Prepare random test instances for BBLIP parameters.
            
            p = inst_storage[str(size)][str(count)]["p"]
            q_1 = inst_storage[str(size)][str(count)]["q_1"]
            q_2 = inst_storage[str(size)][str(count)]["q_2"]
            q = q_1 + q_2
            m = inst_storage[str(size)][str(count)]["m"]
            n = inst_storage[str(size)][str(count)]["n"]
            a = inst_storage[str(size)][str(count)]["a"]
            c = inst_storage[str(size)][str(count)]["c"]
            d = inst_storage[str(size)][str(count)]["d"]
            H = inst_storage[str(size)][str(count)]["H"]
            h = inst_storage[str(size)][str(count)]["h"]
            F = inst_storage[str(size)][str(count)]["F"]
            L = inst_storage[str(size)][str(count)]["L"]
            f = inst_storage[str(size)][str(count)]["f"]

            # Solve for the upper- and lower-bound of dual variables theta_k.
            
            start_time = time.time() 
            obj_ub = solve_obj_ub(q, n, m, c, F, L, f)
            theta_ub_T4 = [math.ceil(obj_ub/f[k]) for k in range(m-n)] + [math.ceil(obj_ub/(1000*2**(-4)))]*n
            theta_lb_T4 = [0]*m
            time_theta_T4 = time.time() - start_time

            start_time = time.time() 
            obj_ub = solve_obj_ub(q, n, m, c, F, L, f)
            theta_ub_T7 = [math.ceil(obj_ub/f[k]) for k in range(m-n)] + [math.ceil(obj_ub/(1000*2**(-7)))]*n
            theta_lb_T7 = [0]*m
            time_theta_T7 = time.time() - start_time

            # Solve for M and M_tilde.
            
            start_time = time.time()
            M = [1000, max(theta_ub_T4), max(f)]
            M = math.ceil(max(M))
            time_M = time.time() - start_time
            
            start_time = time.time()
            M_tilde = [1000, max(sum(F[k][j]*theta_ub_T4[k] for k in range(m)) - c[j] for j in range(n))]
            M_tilde = math.ceil(max(M_tilde))
            time_M_tilde = time.time() - start_time
            
            time_R1 = time_theta_T4 + time_M + time_M_tilde
            time_L2_T4 = time_theta_T4
            time_L2_T7 = time_theta_T7

            big_M = {"obj_ub": obj_ub, "theta_ub_T4": theta_ub_T4, "theta_lb_T4": theta_lb_T4, "theta_ub_T7": theta_ub_T7, "theta_lb_T7": theta_lb_T7, "M": M, "M_tilde": M_tilde, 
                     "t_theta_T4": time_theta_T4, "t_theta_T7": time_theta_T7, "t_M": time_M, "t_M_tilde": time_M_tilde, "t_R1": time_R1, "t_L2_T4": time_L2_T4, "t_L2_T7": time_L2_T7}

            multiple_big_M[count] = big_M
            big_M_storage[size] = multiple_big_M
            
            # Save big-M into a json file.

            json_path = os.getcwd()
            file_name = 'BLIPI_bounds.json'
            fname = os.path.join(json_path, file_name)
            
            with open(fname, 'w') as json_file:
                json.dump(big_M_storage, json_file, indent=4)