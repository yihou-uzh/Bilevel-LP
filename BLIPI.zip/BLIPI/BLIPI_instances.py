## Import packages.

import numpy as np # to generate random instances
import math # to calculate floor and ceiling

import os  # to specify file path
import json # to save instances as .json file

## Bilevel Linear Integer Problem with Interdiction Constraints (BLIPI)

## Design different sizes for the random instances.

q_1_list = []
q_2_list = []
p_list = []
m_list = []

for num_q_1 in range(1):
    for num_q_2 in range(3):
        for num_p in range(2):
            for num_m_ in range(2):
                q_1_list.append(30)
                q_2_list.append((1 + 2*num_q_2)*3)
                p_list.append(5 + 10*num_p)
                m_list.append(20 + 10*num_m_)

## Generate random test instances for BLIPI.

inst_storage = dict()

for size in range(len(q_1_list)):
    
    # Specify problem size.

    q_1 = q_1_list[size]
    q_2 = q_2_list[size]
    q = q_1 + q_2
    p = p_list[size]
    m_ = m_list[size]
    n = q

    # Generate multiple instances for each size.

    multiple_inst = dict()

    for count in range(10):

        # Generate random test instances for BLIPI.

        a = np.random.uniform(1,50,(q))
        c = np.random.uniform(1,50,(n))
        d = np.random.uniform(1,50,(n))
        
        H = np.random.uniform(1,50,(p,q))
        h = []
        for l in range(p):
            h.append(0.4*sum(H[l][i] for i in range(q)))
            
        F_ = np.random.uniform(1,50,(m_,n))
        f_ = []
        for k in range(m_):
            f_.append(2*sum(F_[k][j] for j in range(n)))

        # Convert BLIPI parameters to parameters in the generic BP.

        m = m_+n

        F = []
        for k in range(m_):
            F.append(F_[k])
        for j in range(n):
            row = np.zeros(n)
            row[j] = 1
            F.append(row)

        L = []
        for k in range(m_):
            row = np.zeros(q)
            L.append(row)
        for j in range(n):
            row = np.zeros(q)
            row[j] = -1000
            L.append(row)

        f = []
        for k in range(m_):
            f.append(f_[k])
        for j in range(n):
            f.append(0)
       
        # Store test instances from numpy to list.

        a = np.array(a).tolist()
        c = np.array(c).tolist()
        d = np.array(d).tolist()
        H = np.array(H).tolist()
        h = np.array(h).tolist()
        F = np.array(F).tolist()
        L = np.array(L).tolist()
        f = np.array(f).tolist()
        F_ = np.array(F_).tolist()
        f_ = np.array(f_).tolist()

        inst = {"p": p, "q_1": q_1, "q_2": q_2, "q": q, "m": m, "n": n, "m_": m_, 
                "a": a, "c": c, "d": d, "H": H, "h": h, "F": F, "L": L, "f": f, "F_": F_, "f_": f_}

        multiple_inst[count] = inst

        inst_storage[size] = multiple_inst

## Save test instances into a json file.

json_path = os.getcwd()
file_name = 'BLIPI_instances.json'
fname = os.path.join(json_path, file_name)

with open(fname, 'w') as json_file:
    json.dump(inst_storage, json_file, indent=4)